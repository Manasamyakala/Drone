mod config;
mod loader;
mod preprocessing;
mod detector;
mod tracker;
mod trajectory;
mod simulator;
mod threat_engine;
mod countermeasure;
mod terminal;
mod database;
mod models;
mod utils;

use detector::onnx::OnnxDetector;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("==================================================");
    println!(" AI Powered Counter System for AFVs ");
    println!("==================================================");

    // Load configuration
    config::settings::load();

    // Load YOLO ONNX model
    let _detector = OnnxDetector::new()?;

    println!();
    println!("Configuration Loaded");
    println!("YOLO Model Loaded");
    println!("System Ready");
    println!();

    Ok(())
}

